package com.company.db.dao;

import com.company.db.ConnectionManagerPostresSQL;
import com.company.db.IConnectionManager;
import com.company.pojo.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StudentDAO implements IAbstractDAO<Student> {
    public static class StudentDAOException extends Exception {
    }

    private static IConnectionManager manager;

    static {
        manager = ConnectionManagerPostresSQL.getInstance();
    }

    public List<Student> getAll() throws StudentDAOException {
        List<Student> studentList = new ArrayList<>();

        try {
            Statement statement = manager.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM student");

            while (resultSet.next()) {
                Student student = new Student(
                        (short) resultSet.getInt("id"),
                        resultSet.getString("first_name"),
                        resultSet.getString("second_name"),
                        resultSet.getString("last_name"),
                        resultSet.getDate("birth_date").toLocalDate().toEpochDay(),
                        resultSet.getInt("group_id"));

                studentList.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new StudentDAOException();
        }
        return studentList;
    }

    public Student getById(int id) throws StudentDAOException, SQLException {
        Student student = new Student();

        PreparedStatement preparedStatement = manager.getConnection().prepareStatement("SELECT * FROM student WHERE id = ?");
        preparedStatement.setInt(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            student = new Student(
                    (short) resultSet.getInt("id"),
                    resultSet.getString("first_name"),
                    resultSet.getString("second_name"),
                    resultSet.getString("last_name"),
                    resultSet.getDate("birth_date").toLocalDate().toEpochDay(),
                    resultSet.getInt("group_id"));
        }
        return student;
    }

    public void update(int id, String name) throws SQLException {
        PreparedStatement preparedStatement = manager.getConnection().
                prepareStatement("UPDATE student SET first_name = ? WHERE id = ?");
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, id);
        preparedStatement.executeUpdate();
    }

    public void updateAll(String name) throws SQLException {
        PreparedStatement preparedStatement = manager.getConnection().
                prepareStatement("UPDATE student SET first_name = ?");

        preparedStatement.setString(1, name);
        preparedStatement.addBatch();

        preparedStatement.executeBatch();
    }

    public void deleteById(int id) throws SQLException {
        PreparedStatement preparedStatement = manager.getConnection().prepareStatement("DELETE FROM student WHERE id = ?");
        preparedStatement.setInt(1, id);
        preparedStatement.execute();
    }

    public void deleteAll() throws SQLException {
        Statement statement = manager.getConnection().createStatement();
        statement.execute("DELETE FROM student");
    }

    public void insertOne(Student student) throws SQLException {
        PreparedStatement preparedStatement = manager.getConnection().
                prepareStatement("INSERT INTO student(first_name, second_name, last_name, birth_date, group_id) VALUES(?, ?, ?, ?, ?)");

        preparedStatement.setString(1,
                student.getFirstName());
        preparedStatement.setString(2,
                student.getSecondName());
        preparedStatement.setString(3,
                student.getFamilyName());
        preparedStatement.setDate(4,
                new Date(student.getBirthDay()));
        preparedStatement.setInt(5, 1);

        preparedStatement.executeUpdate();
    }

    @Override
    public void insertAll(Collection<Student> studentList) throws SQLException {

        PreparedStatement preparedStatement = manager.getConnection().
                prepareStatement("INSERT INTO student(first_name, second_name, last_name, birth_date, group_id) VALUES(?, ?, ?, ?, ?)");

        for (Student st : studentList) {
            preparedStatement.setString(1,
                    st.getFirstName());
            preparedStatement.setString(2,
                    st.getSecondName());
            preparedStatement.setString(3,
                    st.getFamilyName());
            preparedStatement.setDate(4,
                    new Date(st.getBirthDay()));
            preparedStatement.setInt(5, 1);
            preparedStatement.addBatch();
        }
        preparedStatement.executeBatch();
    }
}
