package com.company.db.dao;


import java.sql.SQLException;
import java.util.Collection;

public interface IAbstractDAO <T>{

    Collection<T> getAll() throws StudentDAO.StudentDAOException, GroupDAO.GroupDAOException;

    T getById(int id) throws StudentDAO.StudentDAOException, SQLException, GroupDAO.GroupDAOException;

    void update(int id, String name) throws SQLException;

    void updateAll(String name) throws SQLException;

    void deleteById(int id) throws SQLException;

    void deleteAll() throws SQLException;

    void insertOne(T Object) throws SQLException;

    void  insertAll(Collection<T> object) throws SQLException;
}
